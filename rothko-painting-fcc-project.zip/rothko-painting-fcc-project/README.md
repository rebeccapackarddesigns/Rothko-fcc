# Rothko Painting FCC Project

A Pen created on CodePen.io. Original URL: [https://codepen.io/rebeccapackarddesigns/pen/OJQKQVK](https://codepen.io/rebeccapackarddesigns/pen/OJQKQVK).

